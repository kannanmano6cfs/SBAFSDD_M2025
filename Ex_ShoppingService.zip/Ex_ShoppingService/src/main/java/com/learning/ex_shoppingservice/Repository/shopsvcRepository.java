package com.learning.ex_shoppingservice.Repository;

import com.learning.ex_shoppingservice.Model.shopdata;
import org.springframework.data.jpa.repository.JpaRepository;

public interface shopsvcRepository extends JpaRepository<shopdata, Integer> {

}
