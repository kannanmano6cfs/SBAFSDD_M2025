package com.learning.ex_shoppingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExShoppingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExShoppingServiceApplication.class, args);
	}

}
