package com.learning.ex_shoppingservice.Controller;

import com.learning.ex_shoppingservice.Model.Product;
import com.learning.ex_shoppingservice.Model.shopdata;
import com.learning.ex_shoppingservice.Repository.shopsvcRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/shopping")
public class shopsvcController {

    @Autowired
    private shopsvcRepository repo;

    @PostMapping("/addshopping")
    public ResponseEntity<String> addshopping(@RequestBody Product product) {
        shopdata sd=new shopdata();
        sd.setPrdname(product.getPrd_name());
        sd.setPrdcount(product.getPrd_count());
        repo.save(sd);
        return new ResponseEntity<>("Product added to the shopping cart", HttpStatus.OK);
    }
}
