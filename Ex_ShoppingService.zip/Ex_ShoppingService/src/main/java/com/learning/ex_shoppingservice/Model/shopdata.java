package com.learning.ex_shoppingservice.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class shopdata {

    @Id
    @GeneratedValue
    private int sdid;
    private String prdname;
    private int prdcount;

    public shopdata() {
    }

    public shopdata(int sdid, String prdname, int prdcount) {
        this.sdid = sdid;
        this.prdname = prdname;
        this.prdcount = prdcount;
    }

    public int getSdid() {
        return sdid;
    }

    public void setSdid(int sdid) {
        this.sdid = sdid;
    }

    public String getPrdname() {
        return prdname;
    }

    public void setPrdname(String prdname) {
        this.prdname = prdname;
    }

    public int getPrdcount() {
        return prdcount;
    }

    public void setPrdcount(int prdcount) {
        this.prdcount = prdcount;
    }
}
